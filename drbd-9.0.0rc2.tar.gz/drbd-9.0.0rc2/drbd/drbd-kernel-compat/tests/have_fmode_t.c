#include <linux/types.h>

void foo(void)
{
	fmode_t mode;
}
