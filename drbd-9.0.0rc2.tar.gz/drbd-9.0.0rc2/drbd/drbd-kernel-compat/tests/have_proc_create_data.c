#include <linux/proc_fs.h>

#ifndef proc_create_data
void *p = proc_create_data;
#endif
