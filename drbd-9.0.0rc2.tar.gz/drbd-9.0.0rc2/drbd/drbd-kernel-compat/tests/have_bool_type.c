#include <linux/types.h>

bool x;
