/* used to be part of asm/system.h, before that was "Disintegrated" */
#include <asm/system.h>
