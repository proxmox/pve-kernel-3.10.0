#!/bin/sh

echo "/ ls" | targetcli
